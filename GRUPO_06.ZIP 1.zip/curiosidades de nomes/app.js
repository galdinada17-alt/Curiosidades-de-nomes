"use strict";

const API = "https://servicodados.ibge.gov.br/api/v2/censos/nomes";

const formulario = document.getElementById("formulario");
const campoNome = document.getElementById("campoNome");
const botaoPesquisar = document.getElementById("botaoPesquisar");
const botaoLimpar = document.getElementById("botaoLimpar");
const mensagem = document.getElementById("mensagem");
const resultado = document.getElementById("resultado");
const historico = document.getElementById("historico");

const CHAVE_HISTORICO = "historicoNomes";

function mostrarMensagem(texto, tipo = "") {
    mensagem.textContent = texto;
    mensagem.className = tipo;
}

function formatarNumero(numero) {
    return Number(numero || 0).toLocaleString("pt-BR");
}

async function buscarDados(url) {
    const resposta = await fetch(url);

    if (!resposta.ok) {
        throw new Error("Erro HTTP " + resposta.status);
    }

    return await resposta.json();
}

function lerHistorico() {
    try {
        const dados = JSON.parse(
            localStorage.getItem(CHAVE_HISTORICO) || "[]"
        );

        return Array.isArray(dados) ? dados : [];
    } catch {
        return [];
    }
}

function salvarHistorico(nome) {
    let nomes = lerHistorico();

    nomes = nomes.filter(
        item => item.toLowerCase() !== nome.toLowerCase()
    );

    nomes.unshift(nome);

    localStorage.setItem(
        CHAVE_HISTORICO,
        JSON.stringify(nomes.slice(0, 10))
    );

    mostrarHistorico();
}

function mostrarHistorico() {
    historico.replaceChildren();

    const nomes = lerHistorico();

    if (nomes.length === 0) {
        historico.textContent = "Nenhuma pesquisa realizada.";
        return;
    }

    nomes.forEach(nome => {
        const card = document.createElement("article");
        card.className = "card";

        const titulo = document.createElement("h3");
        titulo.textContent = nome;

        const botao = document.createElement("button");
        botao.type = "button";
        botao.textContent = "Pesquisar novamente";

        botao.addEventListener("click", () => {
            campoNome.value = nome;
            pesquisarNome(nome);
        });

        card.append(titulo, botao);
        historico.appendChild(card);
    });
}

async function pesquisarNome(nomeDigitado) {
    const nome = nomeDigitado.trim().replace(/\s+/g, " ");

    if (!nome) {
        mostrarMensagem("Digite um nome para pesquisar.", "erro");
        return;
    }

    if (nome.length > 60 || /[0-9<>]/.test(nome)) {
        mostrarMensagem(
            "Digite um nome válido, sem números.",
            "erro"
        );
        return;
    }

    botaoPesquisar.disabled = true;
    resultado.replaceChildren();

    mostrarMensagem("Consultando os dados do IBGE...");

    try {
        const url = API + "/" + encodeURIComponent(nome);
        const dados = await buscarDados(url);

        if (!Array.isArray(dados) || dados.length === 0) {
            mostrarMensagem(
                "Não foram encontrados dados para esse nome.",
                "erro"
            );
            return;
        }

        const item = dados[0];
        const frequencias = item.res || [];

        if (frequencias.length === 0) {
            mostrarMensagem(
                "Não existem frequências disponíveis para esse nome.",
                "erro"
            );
            return;
        }

        const periodos = frequencias.map(periodo => ({
            periodo: periodo.periodo,
            frequencia: Number(periodo.frequencia) || 0
        }));

        const maior = Math.max(
            ...periodos.map(periodo => periodo.frequencia)
        );

        const total = periodos.reduce(
            (soma, periodo) => soma + periodo.frequencia,
            0
        );

        const card = document.createElement("article");
        card.className = "card";

        const titulo = document.createElement("h2");
        titulo.textContent = "Resultado: " + (item.nome || nome);

        const totalTexto = document.createElement("p");
        totalTexto.textContent =
            "Soma das frequências dos períodos: " +
            formatarNumero(total);

        const maiorTexto = document.createElement("p");
        maiorTexto.textContent =
            "Maior frequência em um período: " +
            formatarNumero(maior);

        const subtitulo = document.createElement("h3");
        subtitulo.textContent = "Frequência por período";

        card.append(titulo, totalTexto, maiorTexto, subtitulo);

        periodos.forEach(periodo => {
            const informacao = document.createElement("div");
            informacao.className = "barra-info";

            const nomePeriodo = document.createElement("span");
            nomePeriodo.textContent = periodo.periodo;

            const valor = document.createElement("strong");
            valor.textContent = formatarNumero(periodo.frequencia);

            informacao.append(nomePeriodo, valor);

            const fundo = document.createElement("div");
            fundo.className = "barra-fundo";

            const barra = document.createElement("div");
            barra.className = "barra-preenchida";

            const percentual = maior > 0
                ? (periodo.frequencia / maior) * 100
                : 0;

            barra.style.width = percentual + "%";

            fundo.appendChild(barra);
            card.append(informacao, fundo);
        });

        const fonte = document.createElement("p");
        fonte.className = "observacao";
        fonte.textContent =
            "Fonte: IBGE. Dados históricos de frequência de nomes.";

        card.appendChild(fonte);
        resultado.appendChild(card);

        mostrarMensagem(
            "Pesquisa realizada com sucesso!",
            "sucesso"
        );

        salvarHistorico(nome);

    } catch (erro) {
        console.error("Erro na pesquisa:", erro);

        mostrarMensagem(
            "Não foi possível acessar a API do IBGE. " +
            "Verifique sua conexão. Detalhe: " + erro.message,
            "erro"
        );
    } finally {
        botaoPesquisar.disabled = false;
    }
}

formulario.addEventListener("submit", evento => {
    evento.preventDefault();
    pesquisarNome(campoNome.value);
});

botaoLimpar.addEventListener("click", () => {
    localStorage.removeItem(CHAVE_HISTORICO);
    mostrarHistorico();

    mostrarMensagem(
        "Histórico apagado com sucesso.",
        "sucesso"
    );
});

mostrarHistorico();